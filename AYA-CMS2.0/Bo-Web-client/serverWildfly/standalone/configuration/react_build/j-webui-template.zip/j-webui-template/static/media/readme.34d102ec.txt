truyền vào dữ liệu
dataFull:{
    percent:10,      //với giá trị nhận vào từ 0 đến 100.
}