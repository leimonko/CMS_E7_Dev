dataFull={{
                title: "loading...",
                percent: this.state.percent,
                speed: {
                  title: "Speed test",
                  number_speed: "39.18 Mbps",
                },
                cmd: {
                  error: {
                    message: "",
                  },
                },
              }}