các hàm trả về:
    -abs_select(data,id) trả về  id của item và data.
            + yêu cầu set lại data giống data được trả về.
data:[
    {
        tabInfo:{
            title:"",      
        },
        sysStyle: { show: "show" },             //nhận giá trị là "show" sẽ được select còn "" thì không
    },
    .....
]